// Etapa 5 - Repeticao e listas

// Laco for simples
for (let i = 1; i <= 5; i++) {
  console.log(`Linha ${i}`);
}

// Lista de notas e media com acumulador
const notas = [8, 6.5, 9, 4];
let soma = 0;
for (let i = 0; i < notas.length; i++) {
  soma += notas[i];
}
console.log(soma / notas.length);

// push e length
notas.push(7);
console.log(notas.length);

// for...of
for (const n of notas) {
  console.log(n);
}

// ---- Checkpoint 3: numeros pares de 2 a 10 ----
for (let i = 2; i <= 10; i += 2) {
  console.log(i);
}

// ---- Checkpoint 4: teste de mesa ----
let total = 0;
for (let i = 1; i <= 4; i++) {
  total += i;
}
console.log(total); // 10
