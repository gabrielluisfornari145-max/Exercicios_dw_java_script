// Etapa 7 - DOM e eventos

const mensagem = document.getElementById("mensagem");
const botao = document.querySelector("#botao");
const contador = document.getElementById("contador");

mensagem.textContent = "O JavaScript está funcionando!";
mensagem.style.color = "green"; // alteracao 1: mensagem verde

let cliques = 0;

botao.addEventListener("click", () => {
  cliques++;
  contador.textContent = cliques;
  botao.textContent = "Clicado!"; // alteracao 2: texto do botao
});
