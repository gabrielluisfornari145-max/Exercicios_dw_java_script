// Etapa 6 - Funcoes

function dobro(x) {
  return x * 2;
}

const media = (lista) => {
  let soma = 0;
  for (const n of lista) {
    soma += n;
  }
  return soma / lista.length;
};

console.log(dobro(21));               // 42
console.log(media([8, 6.5, 9, 4]));   // 6.875

// ---- Checkpoint 1: funcao corrigida ----
// Versao com erro (sem return) devolveria undefined:
//   function soma(a, b) { a + b; }
function soma(a, b) {
  return a + b;
}
console.log(soma(2, 3)); // 5

// ---- Checkpoint 2: ehPar ----
function ehPar(n) {
  return n % 2 === 0;
}
console.log(ehPar(4)); // true
console.log(ehPar(7)); // false
